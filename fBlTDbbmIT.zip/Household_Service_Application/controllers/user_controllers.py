from flask import current_app as app, render_template, request, redirect, url_for, flash, session
from models import *
from datetime import date
from models import db, User, Service, ServiceManagement, ServiceProfessional
from sqlalchemy import or_

logged_user = None
unauthorized_error = False

# Admin Login
@app.route("/user_login", methods=["GET", "POST"])
def user_login():
    global logged_user
    global unauthorized_error
    error = None
    
    if request.method == "POST":
        user_name = request.form.get("user_name")
        user_obj = User.query.filter_by(user_name=user_name).first()
        password = request.form.get("user_password")

        if user_obj:
            if user_obj.user_status == 'Approved':
                if user_obj.user_password == password:
                    logged_user = user_name
                    return redirect(url_for("user_dashboard"))
                else:
                    error = "Password not matched"
            elif user_obj.user_status == 'Rejected' or user_obj.user_status == 'Requested':
                error = "Wait until admin approves you."
        else:
            error = "User name not found"

    if unauthorized_error:
        error = "Please sign in as an user first"
        unauthorized_error = False
        
    return render_template("user_login.html", error=error)

@app.route("/user_register", methods=["GET", "POST"])
def user_register():
    error = None
    if request.method == "POST":
        user_name = request.form.get("user_name")
        user_obj = User.query.get(user_name)
        password = request.form.get("user_password")
        user_email = request.form.get("email_id")
        user_address = request.form.get("user_address")
        pincode = request.form.get("pincode")
        
        if user_obj:
            error = "Username already exists, please use a different username to register"
        else:
            user = User(
                user_name=user_name,
                user_password=password,
                user_email=user_email,
                user_address=user_address,
                user_pincode=pincode
            )
            db.session.add(user)
            db.session.commit()
            return redirect("user_login")
    
    global unauthorized_error
    if unauthorized_error:
        error = "Please sign in as a user first"
        unauthorized_error = False
    return render_template("user_register.html", error=error)


def check_login():
    global logged_user
    if not logged_user:
        global unauthorized_error
        unauthorized_error = True
        return redirect("user_login")

@app.route("/user_dashboard")
def user_dashboard():
    check_login()

    # Get the distinct service types
    service_types = Service.query.with_entities(Service.service_type).distinct()
    services_by_type = {}

    for service_type in service_types:
        services_by_type[service_type.service_type] = Service.query.filter_by(service_type=service_type.service_type).all()

    # Fetch the recent service bookings for the logged-in user
    service_requests = ServiceManagement.query.filter_by(user_name=logged_user).order_by(ServiceManagement.date_of_request.desc()).all()

    return render_template("user_dashboard.html",
                           service_types=service_types, 
                           services_by_type=services_by_type, 
                           service_requests=service_requests)

@app.route('/book_service/<int:service_id>', methods=['POST'])
def book_service(service_id):
    # Ensure `logged_user` is set correctly (e.g., from session)
    user_name = logged_user  # Assuming you store this in the session

    if not user_name:
        flash("Please log in to book a service.", "error")
        return redirect(url_for('user_login'))

    service = Service.query.get(service_id)
    user = User.query.filter_by(user_name=user_name).first()

    if not service or not user:
        flash("Service or user not found", "error")
        return redirect(request.referrer or url_for('user_dashboard'))

    try:
        # Create the service request
        service_request = ServiceManagement(
            service_name=service.service_name,
            service_id=service.service_id,
            user_name=user.user_name,
            service_professional_name=None,  # Will be assigned later
            date_of_request=date.today(),
            service_status='requested'
        )

        # Increment the service count
        service.service_count += 1

        # Save the request and update the service
        db.session.add(service_request)
        db.session.commit()

        flash("Service booked successfully!", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"An error occurred while booking the service: {e}", "error")

    return redirect(request.referrer or url_for('user_dashboard'))


@app.route('/delete_service_request', methods=['POST'])
def delete_service_request():
    # Get the service request ID from the form (change to 'service_request_id')
    service_request_id = request.form.get('service_request_id')

    if not service_request_id:
        flash("Invalid service request", "error")
        return redirect(request.referrer or url_for('admin_dashboard'))

    # Fetch the service request to delete using 'service_request_id'
    service_request = ServiceManagement.query.filter_by(service_request_id=service_request_id).first()

    if not service_request:
        flash("Service request not found", "error")
        return redirect(request.referrer or url_for('admin_dashboard'))

    try:
        # Fetch the associated service from the Service table
        service = Service.query.filter_by(service_id=service_request.service_id).first()

        # Decrement the service count if it's greater than 0
        if service and service.service_count > 0:
            service.service_count -= 1
            print(f"Service count decremented. New count: {service.service_count}")

        # Delete the service request
        db.session.delete(service_request)
        db.session.commit()
        flash("Service request deleted successfully!", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting service request: {str(e)}", "error")

    return redirect(request.referrer or url_for('admin_dashboard'))


@app.route('/user_search', methods=['GET', 'POST'])
def user_search_results():
    check_login()
    # Get search criteria from the request
    service_type = request.args.get('service_type', '')
    query = request.args.get('query', '')

    # Retrieve distinct service types for the dropdown
    service_types = db.session.query(Service.service_type).distinct().all()

    # Flatten list of tuples into a list
    service_types = [stype[0] for stype in service_types]

    # Filter results based on selected service type and matching characters in service name
    results = Service.query.filter(
        func.lower(Service.service_type) == service_type.lower(),
        func.lower(Service.service_name).like(f"%{query.lower()}%")
    ).all()

    # Render search results with service types for dropdown
    return render_template(
        'user_search.html', 
        service_type=service_type, 
        query=query, 
        results=results, 
        service_types=service_types
    )

@app.route('/user_summary')
def user_summary():
    # Ensure the user is logged in by checking the global logged_user variable
    check_login()  # This will ensure the user is logged in (as per your original code)

    # Query the ServiceManagement table for service requests belonging to the logged-in user
    service_data = db.session.query(
        Service.service_type,  # Select service_type from the Service table
        db.func.count(ServiceManagement.service_request_id).label('request_count')  # Count the service requests
    ).join(
        Service,  # Join with the Service table using the service_id
        ServiceManagement.service_id == Service.service_id
    ).filter(
        ServiceManagement.user_name == logged_user  # Filter by the logged-in user's name
    ).group_by(
        Service.service_type  # Group by service_type
    ).all()

    # Prepare the data to be passed to the template
    services_data = [{'service_type': service.service_type, 'request_count': service.request_count} for service in service_data]

    # Render the summary template and pass the services data
    return render_template('user_summary.html', services_data=services_data)

# Route to display the service remark form
@app.route('/service_remark/<int:service_request_id>', methods=['GET', 'POST'])
def service_remark(service_request_id):
    check_login()  # Ensure user is logged in
    
    # Fetch the service request details
    service_request = ServiceManagement.query.get(service_request_id)
    if not service_request:
        flash("Service request not found.", "danger")
        return redirect(url_for('user_dashboard'))
    
    if request.method == 'POST':
        try:
            # Get form data
            remark = request.form.get('remark', '').strip()
            rating = request.form.get('rating')

            # Validate inputs
            if not rating or not rating.isdigit() or not (1 <= int(rating) <= 5):
                flash("Rating must be a number between 1 and 5.", "danger")
                return redirect(url_for('service_remark', service_request_id=service_request_id))

            # Update service details
            service_request.remark = remark
            service_request.service_rating = int(rating)
            service_request.service_status = 'completed'  # Automatically set status to completed
            service_request.date_of_completion = date.today()  # Use date, not datetime

            db.session.commit()

            flash("Service updated successfully!", "success")
            return redirect(url_for('user_dashboard'))
        except Exception as e:
            db.session.rollback()
            flash(f"An error occurred while updating the service: {str(e)}", "danger")

    return render_template('service_remark.html', service_request=service_request)


#User Profile Update
@app.route('/user_profile', methods=['GET', 'POST'])
def user_profile():
    check = check_login()
    if check:
        return check
    existing_user = logged_user
    if request.method == "POST":
        # fetch data from html
        print(request.form)
        user_id = request.form.get("user_id")
        user_name = request.form.get("user_name")
        user_email = request.form.get("user_email")
        user_password = request.form.get("user_password")
        user_address = request.form.get("user_address")
        user_pincode = request.form.get("user_pincode")
        existing_user = User.query.filter_by(user_name=logged_user).first()

        if existing_user:
            existing_user.user_name = user_name
            existing_user.user_email = user_email
            existing_user.user_password = user_password
            existing_user.user_address = user_address
            existing_user.user_pincode = user_pincode
            db.session.commit()
            flash("User updated successfully")
        else:
            flash("User not found")
        return redirect(url_for("user_dashboard"))
    existing_user=User.query.filter_by(user_name=logged_user).first()
    return render_template("user_profile.html", existing_user=existing_user)

# User Logout
@app.route("/user_logout")
def user_logout():
    global logged_user
    logged_user = None
    return redirect("user_login")