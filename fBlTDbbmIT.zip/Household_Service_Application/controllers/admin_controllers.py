from flask import current_app as app, render_template, request, redirect, url_for, flash
from models import *
from sqlalchemy.orm import joinedload
import uuid
from models import db, Service, User, ServiceProfessional, ServiceManagement
import os
from werkzeug.utils import secure_filename

# Define the upload folder for storing the uploaded documents
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf'}

# Ensure the upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


logged_admin = None
unauthorized_error = False

# Admin Login
@app.route("/admin_login", methods=["GET", "POST"])
def admin_login():
    global logged_admin
    global unauthorized_error
    error = None
    
    if request.method == "POST":
        admin_name = request.form.get("admin_name")
        admin_obj = Admin.query.filter_by(admin_name=admin_name).first()
        password = request.form.get("admin_password")

        if admin_obj:
            # admin name matched
            if admin_obj.admin_password == password:
                # admin password matched
                logged_admin = admin_name
                return redirect(url_for("admin_dashboard"))
            else:
                error = "Password not matched"
        else:
            error = "Admin name not matched"

    if unauthorized_error:
        error = "Please sign in as an admin first"
        unauthorized_error = False
        
    return render_template("admin_login.html", error=error)

def check_login():
    global logged_admin
    global unauthorized_error
    if not logged_admin:
        unauthorized_error = True
        return redirect(url_for("admin_login"))
    return None

def get_service_requests():
    # Query the service management table to get all service requests
    service_requests = db.session.query(ServiceManagement).all()
    
    # Prepare the data to send to the admin dashboard
    service_request_data = []
    for request in service_requests:
        service_request_data.append({
            'service_name': request.service.name,
            'user_name': request.user.user_name,
            'date_of_request': request.date_of_request,
            'service_status': request.service_status
        })
    
    return service_request_data

# Admin Dashboard
@app.route('/admin_dashboard', methods=['GET', 'POST'])
def admin_dashboard():
    # Fetch all services, professionals, and users
    services = Service.query.all()
    service_professionals = ServiceProfessional.query.all()
    users = User.query.all()  # Added user query

    if request.method == 'POST':
        action = request.form.get('action')
        professional_id = request.form.get('professional_id')
        user_id = request.form.get('user_id')  # Added user_id handling

        # Handle document upload and saving for service professionals
        if 'upload_doc' in request.files:
            file = request.files['upload_doc']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(UPLOAD_FOLDER, filename)
                file.save(filepath)

                # Create a new service professional
                new_professional = ServiceProfessional(
                    service_professional_name=request.form['service_professional_name'],
                    service_professional_email=request.form['service_professional_email'],
                    service_professional_password=request.form['service_professional_password'],
                    upload_doc=filename,  # Store only the filename, not the full path
                    service_type=request.form['service_type']
                )
                db.session.add(new_professional)
                db.session.commit()
                flash("Service professional registered successfully!", "success")

        # Handle actions for service professionals
        if professional_id:
            professional = ServiceProfessional.query.get(professional_id)
            if professional:
                if action == 'approve':
                    professional.status = 'Approved'
                    flash("Professional approved successfully!", "success")
                elif action == 'reject':
                    professional.status = 'Rejected'
                    flash("Professional rejected successfully!", "warning")
                elif action == 'delete':
                    db.session.delete(professional)
                    flash("Professional deleted successfully!", "danger")
                db.session.commit()

        # Handle actions for users
        if user_id:
            user = User.query.get(user_id)
            if user:
                if action == 'approve_user':
                    user.user_status = 'Approved'
                    flash("User approved successfully!", "success")
                elif action == 'reject_user':
                    user.user_status = 'Rejected'
                    flash("User rejected successfully!", "warning")
                elif action == 'delete_user':
                    db.session.delete(user)
                    flash("User deleted successfully!", "danger")
                db.session.commit()

    # Fetch all service requests (unchanged)
    service_requests = ServiceManagement.query.all()

    return render_template(
        'admin_dashboard.html',
        services=services,
        service_professionals=service_professionals,
        service_requests=service_requests,
        users=users  # Added users for the template
    )



# Create a new service
@app.route("/service_create", methods=["POST", "GET"])
def service_create():
    check = check_login()
    if check:
        return check

    if request.method == "POST":
        # fetch data from html
        service_name = request.form.get("service_name")
        price = request.form.get("price")
        time_required = request.form.get("time_required")
        service_type = request.form.get("service_type")
        description = request.form.get("description")
        new_service = Service(
            service_name=service_name,
            price=price,
            service_type=service_type,
            time_required=time_required,
            description=description)
        db.session.add(new_service)
        db.session.commit()
        flash("Service created successfully")
        return redirect(url_for("admin_dashboard"))
    # Fetch service types dynamically from the database
    service_types = db.session.query(Service.service_type).distinct().all()
    # Extract service types as a list
    service_type = [st[0] for st in service_types]
    return render_template("service_create.html", service_type=service_type)

# Edit a service
@app.route("/service_edit", methods=["GET", "POST"])
def edit_service():
    check = check_login()
    if check:
        return check

    if request.method == "POST":
        # fetch data from html
        service_id = request.form.get("service_id")
        service_name = request.form.get("service_name")
        price = request.form.get("price")
        service_type = request.form.get("service_type")
        time_required = request.form.get("time_required")
        description = request.form.get("description")
        existing_service = Service.query.get(service_id)

        if existing_service:
            existing_service.service_name = service_name
            existing_service.price = price
            existing_service.service_type = service_type
            existing_service.time_required = time_required
            existing_service.description = description
            db.session.commit()
            flash("Service updated successfully")
        else:
            flash("Service not found")

        return redirect(url_for("admin_dashboard"))

    services = Service.query.all()
    return render_template("service_edit.html", services=services)

# Delete a service
@app.route("/service_delete", methods=["POST", "GET"])
def service_delete():
    check = check_login()
    if check:
        return check

    if request.method == "POST":
        # fetch data from html
        service_id = request.form.get("service_id")
        service_obj_to_delete = Service.query.get(service_id)
        print(service_id, service_obj_to_delete)
        if service_obj_to_delete:
            db.session.delete(service_obj_to_delete)
            db.session.commit()
            flash("Service deleted successfully")
        else:
            flash("Service not found")

        return redirect(url_for("service_delete"))

    services = Service.query.all()
    return render_template("service_delete.html", services=services)

# Relations
@app.route("/relational_management", methods=["GET", "POST"])
def relational_management():
    check = check_login()
    if check:
        return check

    if request.method == "POST":
        service_id = request.form.get("service_id")
        service_obj = Service.query.get(service_id)
        assigned_service_id_list = request.form.getlist("assigned_service")
        price_list = dict([(service_id, request.form.get(f"price_{service_id}")) for service_id in assigned_service_id_list])

        if service_obj:
            for sp_id in assigned_service_id_list:
                service_management = ServiceManagement.query.filter_by(service_id=service_id, service_professional_id=sp_id).first()
                if service_management:
                    service_management.price = price_list[sp_id]
                else:
                    new_sm = ServiceManagement(
                        service_request_id=str(uuid.uuid4()),
                        user_id=None,  # Set to actual user id if available
                        service_id=service_id,
                        service_professional_id=sp_id,
                        status='assigned'
                    )
                    db.session.add(new_sm)

            db.session.commit()
            flash("Services assigned successfully")
        else:
            flash("Service not found")

        return redirect(url_for("admin_dashboard"))

    services = Service.query.all()
    return render_template("relational_management.html", services=services)

# Approve Professional
@app.route('/approve_professional/<int:professional_id>', methods=['POST'])
def approve_professional(professional_id):
    check = check_login()
    if check:
        return check

    professional = ServiceProfessional.query.get(professional_id)
    if professional:
        professional.status = 'Approved'
        db.session.commit()
        flash("Professional approved successfully")
    else:
        flash("Professional not found")

    return redirect(url_for('admin_dashboard'))

# Reject Professional
@app.route('/reject_professional/<int:professional_id>', methods=['POST'])
def reject_professional(professional_id):
    check = check_login()
    if check:
        return check

    professional = ServiceProfessional.query.get(professional_id)
    if professional:
        professional.status = 'Rejected'
        db.session.commit()
        flash("Professional rejected successfully")
    else:
        flash("Professional not found")

    return redirect(url_for('admin_dashboard'))

# Delete Professional
@app.route('/delete_professional/<int:professional_id>', methods=['POST'])
def delete_professional(professional_id):
    check = check_login()
    if check:
        return check

    professional = ServiceProfessional.query.get(professional_id)
    if professional:
        db.session.delete(professional)
        db.session.commit()
        flash("Professional deleted successfully")
    else:
        flash("Professional not found")

    return redirect(url_for('admin_dashboard'))

@app.route('/approve_user/<int:user_id>', methods=['POST'])
def approve_user(user_id):
    check = check_login()
    if check:
        return check

    user = User.query.get(user_id)
    if user:
        user.user_status = 'Approved'
        db.session.commit()
        flash("User approved successfully", "success")
    else:
        flash("User not found", "error")

    return redirect(url_for('admin_dashboard'))

@app.route('/reject_user/<int:user_id>', methods=['POST'])
def reject_user(user_id):
    check = check_login()
    if check:
        return check

    user = User.query.get(user_id)
    if user:
        user.user_status = 'Rejected'
        db.session.commit()
        flash("User rejected successfully", "warning")
    else:
        flash("User not found", "error")

    return redirect(url_for('admin_dashboard'))

# Admin Search
@app.route('/admin_search', methods=['GET', 'POST'])
def admin_search_results():
    check = check_login()
    if check:
        return check

    category = request.args.get('category', '')  # Category selected for search
    query = request.args.get('query', '').strip()  # Input query
    results = []

    if category == 'services':
        # Case-insensitive search in the Service model by name or service type
        results = Service.query.filter(
            func.lower(Service.service_name).like(f"%{query.lower()}%") |
            func.lower(Service.service_type).like(f"%{query.lower()}%")
        ).all()

    elif category == 'customers':
        # Case-insensitive search in the User model (customers) by name or email
        results = User.query.filter(
            func.lower(User.user_name).like(f"%{query.lower()}%") |
            func.lower(User.user_email).like(f"%{query.lower()}%")
        ).all()

    elif category == 'professionals':
        # Case-insensitive search in the ServiceProfessional model by name or service type
        results = ServiceProfessional.query.filter(
            func.lower(ServiceProfessional.service_professional_name).like(f"%{query.lower()}%") |
            func.lower(ServiceProfessional.service_type).like(f"%{query.lower()}%")
        ).all()

    elif category == 'requests':
        # Case-insensitive search in the ServiceManagement model by service status or service name
        # Join ServiceManagement with Service for service_name
        results = db.session.query(
            ServiceManagement.service_request_id,
            Service.service_name.label("service_name"),
            ServiceManagement.user_name.label("user_name"),
            ServiceManagement.service_professional_name,
            ServiceManagement.service_status,
            ServiceManagement.date_of_request,
            ServiceManagement.date_of_completion
        ).join(Service, ServiceManagement.service_id == Service.service_id).filter(
            func.lower(ServiceManagement.service_status).like(f"%{query.lower()}%") |
            func.lower(Service.service_name).like(f"%{query.lower()}%") |
            func.lower(ServiceManagement.user_name).like(f"%{query.lower()}%") |
            func.lower(ServiceManagement.service_professional_name).like(f"%{query.lower()}%")
        ).all()

    return render_template('admin_search.html', category=category, query=query, results=results)

@app.route('/delete_service_request', methods=['POST'])
def admin_delete_service_request():
    # Get the service request ID from the form (change to 'service_request_id')
    service_request_id = request.form.get('service_request_id')

    if not service_request_id:
        flash("Invalid service request", "error")
        return redirect(request.referrer or url_for('admin_dashboard'))

    # Fetch the service request to delete using 'service_request_id'
    service_request = ServiceManagement.query.filter_by(service_request_id=service_request_id).first()

    if not service_request:
        flash("Service request not found", "error")
        return redirect(request.referrer or url_for('admin_dashboard'))

    try:
        # Fetch the associated service from the Service table
        service = Service.query.filter_by(service_id=service_request.service_id).first()

        # Decrement the service count if it's greater than 0
        if service and service.service_count > 0:
            service.service_count -= 1
            print(f"Service count decremented. New count: {service.service_count}")

        # Delete the service request
        db.session.delete(service_request)
        db.session.commit()
        flash("Service request deleted successfully!", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting service request: {str(e)}", "error")

    return redirect(request.referrer or url_for('admin_dashboard'))


# Summary
@app.route("/admin_summary")
def summary():
    services_data = [
        {
            "service_id": service.service_id,
            "service_name": service.service_type,
            "request_count": (service.service_count),  # Count of requests for each service
        }
        for service in Service.query.all()
    ]
    return render_template("admin_summary.html", services_data=services_data)


@app.route("/admin_logout")
def logout():
    global logged_admin
    global unauthorized_error
    logged_admin = None
    unauthorized_error = False
    return render_template("index.html")
