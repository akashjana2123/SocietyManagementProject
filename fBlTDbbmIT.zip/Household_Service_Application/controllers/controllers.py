from flask import current_app as app, render_template
from models import *
from controllers.admin_controllers import *
from controllers.user_controllers import *
from controllers.service_professional_controllers import *

@app.route('/')
def home():
    obj = Admin.query.first()
    if obj is None:
        # Handle the case when there is no admin record
        admin_name = "No Admin Found"
    else:
        admin_name = obj.admin_name
    return render_template("index.html", admin_name=admin_name)