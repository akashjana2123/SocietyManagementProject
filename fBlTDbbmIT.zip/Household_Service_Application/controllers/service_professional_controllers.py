from flask import current_app as app, render_template, request, redirect, url_for, flash, session, send_from_directory, current_app
from models import *
from werkzeug.utils import secure_filename
from models import ServiceManagement
import os
from datetime import date

logged_service_professional = None
unauthorized_error = False

# Define the upload folder and allowed file types
app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), 'uploads')  # The 'uploads' folder will be in your current working directory
# app.config['ALLOWED_EXTENSIONS'] = {'pdf', 'png', 'jpg', 'jpeg', 'gif'}
app.config['ALLOWED_EXTENSIONS'] = {'pdf'}  # Define allowed file types

# Ensure the upload folder exists, if not, create it
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Route for service professional registration
@app.route("/service_professional_register", methods=["GET", "POST"])
def service_professional_register():
    error = None
    service_types = Service.query.with_entities(Service.service_type).distinct()  # Get distinct service types from the service table

    if request.method == "POST":
        # Collecting data from the form
        service_professional_name = request.form.get("service_professional_name")
        service_professional_email = request.form.get("service_professional_email")
        password = request.form.get("service_professional_password")
        upload_doc = request.files.get("upload_doc")  # Assuming file input in the form
        service_professional_address = request.form.get("service_professional_address")
        service_professional_pincode = request.form.get("service_professional_pincode")
        date_created = date.today()
        description = request.form.get("description")
        experience = request.form.get("experience")
        service_type = request.form.get("service_type")  # Get selected service type from the form

        # Validate that the file is provided
        if not upload_doc:
            error = "Please upload a document."
        else:
            # Save the uploaded document
            filename = secure_filename(upload_doc.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            upload_doc.save(file_path)

            # Check if the service professional name already exists
            service_professional_obj = ServiceProfessional.query.filter_by(service_professional_name=service_professional_name).first()
            if service_professional_obj:
                error = "Service professional name already taken, please choose another one."
            else:
                # Create new service professional object
                new_service_professional = ServiceProfessional(
                    service_professional_name=service_professional_name,
                    service_professional_email=service_professional_email,
                    service_professional_password=password,
                    upload_doc=filename,
                    service_professional_address=service_professional_address,
                    service_professional_pincode=service_professional_pincode,
                    date_created = date_created,
                    description = description,
                    experience = experience,
                    service_type=service_type,  # Saving the selected service type
                    status="Requested"  # Default status is Requested
                )

                db.session.add(new_service_professional)
                db.session.commit()  # Commit after adding the service professional to the session
                
                return redirect(url_for("service_professional_login"))  # Redirect to login page after successful registration

    global unauthorized_error
    if unauthorized_error:
        error = "Please sign in first."
        unauthorized_error = False

    return render_template("service_professional_register.html", error=error, service_types=service_types)  # Pass service types to the template

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)

# Route for service professional login
@app.route("/service_professional_login", methods=["GET", "POST"])
def service_professional_login():
    error = None
    if request.method == "POST":
        service_professional_name = request.form.get("service_professional_name")
        password = request.form.get("service_professional_password")

        # Search for the service professional by service_professional_name
        service_professional_obj = ServiceProfessional.query.filter_by(service_professional_name=service_professional_name).first()

        if service_professional_obj:
            # Check the status of the service professional
            if service_professional_obj.status == 'Approved':
                # Check if the password matches
                if service_professional_obj.service_professional_password == password:
                    global logged_service_professional
                    logged_service_professional = service_professional_name
                    return redirect(url_for("service_professional_dashboard"))
                else:
                    error = "Passwords do not match."
            elif service_professional_obj.status == 'Rejected' or service_professional_obj.status == 'Requested':
                error = "Wait until admin approves you."
        else:
            error = "Service professional name not found."

    global unauthorized_error
    if unauthorized_error:
        error = "Please sign in first."
        unauthorized_error = False
    
    return render_template("service_professional_login.html", error=error)

@app.route("/accepted_services", methods=["GET"])
def accepted_services():
    # Get the logged-in service professional's name

    # Check if a service professional is logged in
    if not logged_service_professional:
        flash("You must be logged in to view accepted services.", "error")
        return redirect(url_for('service_professional_login'))

    # Query the ServiceManagement table for services assigned to the logged-in service professional
    accepted_services = ServiceManagement.query.filter_by(service_professional_name=logged_service_professional).all()

    # Render the template and pass the accepted services to it
    return render_template("service_professional_dashboard.html", accepted_services=accepted_services)


def check_login():
    global logged_service_professional
    if not logged_service_professional:
        global unauthorized_error
        unauthorized_error = True
        return redirect("service_professional_login")

    # Check the status of the logged-in service professional
    service_professional_obj = ServiceProfessional.query.filter_by(service_professional_name=logged_service_professional).first()
    if service_professional_obj and service_professional_obj.status != 'Approved':
        return render_template("service_professional_dashboard.html", error="Wait until admin approves you.")

@app.route("/service_professional_dashboard", methods=["GET", "POST"])
def service_professional_dashboard():
    check_result = check_login()
    if check_result:
        return check_result  # Return the error page if not approved

    if request.method == "POST":
        # Handle the accept service request
        service_id = request.form.get('service_id')
        if service_id:
            # Find the service request with the provided service_id
            service_obj = Service.query.filter_by(id=service_id).first()
            if service_obj and (service_obj.service_professional_name is None):
                # Update the service's service_professional_name to the logged-in professional
                service_obj.service_professional_name = logged_service_professional
                db.session.commit()

    # Fetch all available services with the requested status
    all_services = ServiceManagement.query.filter_by(service_status='requested').all()

    # Fetch services accepted by the logged-in professional
    accepted_services = ServiceManagement.query.filter_by(service_professional_name=logged_service_professional, service_status='in_progress').all()

    # Fetch services with status 'completed' and assigned to the logged-in professional
    closed_services = ServiceManagement.query.filter_by(service_professional_name=logged_service_professional, service_status='completed').all()

    return render_template("service_professional_dashboard.html",
                           all_services=all_services,
                           accepted_services=accepted_services,
                           closed_services=closed_services)  # Pass closed_services to the template


@app.route("/accept_service/<int:service_request_id>", methods=["POST"])
def accept_service(service_request_id):
    global logged_service_professional  # Declare it as global here
    
    # Fetch the service request from the database
    service_request = ServiceManagement.query.get(service_request_id)
    
    # Ensure the service request exists
    if not service_request:
        flash("Service request not found", "error")
        return redirect(url_for('service_professional_dashboard'))  # Redirect to dashboard
    
    # Ensure the service professional is logged in
    if not logged_service_professional:
        flash("You must be logged in to accept a service", "error")
        return redirect('/service_professional_login')  # Redirect to login if not logged in

    # Call the accept_service method on the service request
    service_request.accept_service(logged_service_professional)

    # Fetch accepted services for the logged-in professional
    accepted_services = ServiceManagement.query.filter_by(service_professional_name=logged_service_professional, service_status='in_progress').all()

    # Redirect back to the service professional dashboard after accepting the service
    flash("Service accepted successfully!", "success")
    return render_template('service_professional_dashboard.html', accepted_services=accepted_services)

#service professional Profile Update
@app.route('/service_professional_profile', methods=['GET', 'POST'])
def service_professional_profile():
    check = check_login()
    if check:
        return check

    # Fetch the existing logged-in service professional
    existing_service_professional = ServiceProfessional.query.filter_by(service_professional_name=logged_service_professional).first()

    # Fetch available service types from the service table
    service_types = Service.query.all()  # Adjust this if your table name is different
    
    if request.method == "POST":
        if not existing_service_professional:
            flash("Service professional not found.", "error")
            return redirect(url_for("service_professional_dashboard"))

        # Fetch data from the form
        service_professional_name = request.form.get("service_professional_name")
        service_professional_email = request.form.get("service_professional_email")
        service_professional_password = request.form.get("service_professional_password")
        service_professional_address = request.form.get("service_professional_address")
        service_professional_pincode = request.form.get("service_professional_pincode")
        description = request.form.get("description")
        experience = request.form.get("experience")
        service_type = request.form.get("service_type")
        upload_doc = request.files.get("upload_doc")  # File input

        # Update fields
        existing_service_professional.service_professional_name = service_professional_name
        existing_service_professional.service_professional_email = service_professional_email
        existing_service_professional.service_professional_password = service_professional_password
        existing_service_professional.service_professional_address = service_professional_address
        existing_service_professional.service_professional_pincode = service_professional_pincode
        existing_service_professional.description = description
        existing_service_professional.experience = experience
        existing_service_professional.service_type = service_type

        # Handle file upload
        if upload_doc:
            filename = secure_filename(upload_doc.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

            # Remove old file if exists
            old_file = existing_service_professional.upload_doc
            if old_file:
                old_file_path = os.path.join(app.config['UPLOAD_FOLDER'], old_file)
                if os.path.exists(old_file_path):
                    os.remove(old_file_path)

            # Save new file
            upload_doc.save(file_path)
            existing_service_professional.upload_doc = filename

        # Commit changes
        db.session.commit()
        flash("Service Professional updated successfully.", "success")
        return redirect(url_for("service_professional_dashboard"))

    return render_template(
        "service_professional_profile.html",
        existing_service_professional=existing_service_professional,
        service_types=service_types  # Pass the service types to the template
    )

@app.route('/service_professional_search', methods=['GET', 'POST'])
def service_professional_search():
    global logged_service_professional  # Use the global variable for the logged-in service professional
    search_results = []
    search_query = request.form.get('search_query', '')
    status_filter = request.form.get('status_filter', 'requested')  # Default filter is 'requested'

    # Ensure the service professional is logged in
    if not logged_service_professional:
        flash("You must be logged in to view this page", "error")
        return redirect('/service_professional_login')  # Redirect to login if not logged in

    if request.method == 'POST':
        # Base query filtered by status and assigned to the logged-in professional
        query = ServiceManagement.query.filter_by(service_status=status_filter)

        # Add additional filters for search if a query is provided
        if search_query:
            query = query.filter(
                (ServiceManagement.date_of_request.like(f"%{search_query}%")) |
                (ServiceManagement.remark.like(f"%{search_query}%"))
            )
        
        # Fetch the filtered results
        search_results = query.all()

    return render_template(
        'service_professional_search.html',
        search_results=search_results,
        status_filter=status_filter,
        search_query=search_query,
        logged_service_professional=logged_service_professional
    )

@app.route("/service_professional_summary")
def service_professional_summary():
    services_data = [
        {
            "service_id": service.service_id,
            "service_name": service.service_type,
            "request_count": (service.service_count),  # Count of requests for each service
        }
        for service in Service.query.all()
    ]
    return render_template("service_professional_summary.html", services_data=services_data)

@app.route("/service_professional_logout")
def service_professional_logout():
    global logged_service_professional
    logged_service_professional = None
    return redirect("service_professional_login")