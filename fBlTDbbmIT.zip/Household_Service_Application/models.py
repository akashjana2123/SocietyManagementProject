import datetime
from database import db
from sqlalchemy import Enum, Table
from sqlalchemy.sql import func

# Define the association table for the many-to-many relationship
service_management_association = Table(
    'service_management_association',
    db.Model.metadata,
    db.Column('service_id', db.Integer, db.ForeignKey('service.service_id'), primary_key=True),
    db.Column('service_request_id', db.Integer, db.ForeignKey('service_management.service_request_id'), primary_key=True)
)

# User-Credentials (Admin, Customer, Service Professional)
class Admin(db.Model):
    __tablename__ = "admin"
    admin_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    admin_name = db.Column(db.String, nullable=False)
    admin_password = db.Column(db.String, nullable=False)

class User(db.Model):
    __tablename__ = "user"
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_name = db.Column(db.String, nullable=False)
    user_email = db.Column(db.String, nullable=True)
    user_password = db.Column(db.String, nullable=False)
    user_address = db.Column(db.String, nullable=True)
    user_pincode = db.Column(db.Integer, nullable=True)
    service_request_count = db.Column(db.Integer, default=0)
    user_status = db.Column(db.Enum('Requested', 'Approved', 'Rejected', name='user_status'), nullable=False, default='Requested')

class ServiceProfessional(db.Model):
    __tablename__ = "service_professional"
    service_professional_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    service_professional_name = db.Column(db.String, nullable=False)
    service_professional_email = db.Column(db.String, nullable=True)
    service_professional_password = db.Column(db.String, nullable=False)
    upload_doc = db.Column(db.String, nullable=False)
    service_professional_address = db.Column(db.String, nullable=True)
    service_professional_pincode = db.Column(db.Integer, nullable=True)
    status = db.Column(db.Enum('Requested', 'Approved', 'Rejected', name='status'), nullable=False, default='Requested')
    date_created = db.Column(db.Date, nullable=False, default=func.current_date())
    description = db.Column(db.String, nullable=True, default=None)
    experience = db.Column(db.Integer, nullable=True, default=0)
    service_type = db.Column(db.String, nullable=False)

# Relational database (Service and Service Management)
class Service(db.Model):
    __tablename__ = "service"
    service_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    service_name = db.Column(db.String, nullable=False)
    price = db.Column(db.Float, nullable=False, default=0.0)
    service_type = db.Column(db.String, nullable=False)
    time_required = db.Column(db.Integer, nullable=False)
    description = db.Column(db.String)
    service_count = db.Column(db.Integer, default=0)

class ServiceManagement(db.Model):
    __tablename__ = "service_management"
    service_request_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    service_name = db.Column(db.String, db.ForeignKey("service.service_name"), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey("service.service_id"), nullable=False)
    service_professional_name = db.Column(db.String, db.ForeignKey("service_professional.service_professional_name"), nullable=False)
    user_name = db.Column(db.String, db.ForeignKey("user.user_name"), nullable=False)
    date_of_request = db.Column(db.Date, nullable=True)
    date_of_completion = db.Column(db.Date, nullable=True)
    service_status = db.Column(db.Enum('requested', 'assigned', 'in_progress', 'completed', name='status'), nullable=False, default='requested')
    remark = db.Column(db.String, nullable=True)
    service_rating = db.Column(db.Integer, nullable=True)


    user = db.relationship('User', backref='service_requests')
    service_professional = db.relationship('ServiceProfessional', backref='service_requests')

    # Method to get all accepted services
    def accepted_services(self):
        return ServiceManagement.query.filter_by(service_professional_name=self.service_professional_name, service_status='assigned').all()
    
    # Method to accept a service request
    def accept_service(self, service_professional_name):
        if self.service_status == 'requested' and not self.service_professional_name:
            self.service_professional_name = service_professional_name
            self.service_status = 'in_progress'  # Set status to 'in_progress' upon acceptance
            db.session.commit()